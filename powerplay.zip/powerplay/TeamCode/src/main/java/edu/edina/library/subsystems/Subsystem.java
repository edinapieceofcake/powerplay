package edu.edina.library.subsystems;

public abstract class Subsystem {
    public abstract void update();
}
